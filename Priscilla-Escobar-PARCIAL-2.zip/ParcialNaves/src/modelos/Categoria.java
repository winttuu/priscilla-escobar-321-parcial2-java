
package modelos;

public enum Categoria {
    CIENTIFICA,
    TRANSPORTE,
    MILITAR
}
