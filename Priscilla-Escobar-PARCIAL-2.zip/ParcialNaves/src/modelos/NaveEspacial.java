
package modelos;


public class NaveEspacial implements CSVSerializable, Comparable<NaveEspacial> {
    private static final Long serialVersionUID = 1L;

    private int id;
    private String nombre;
    private Categoria categoria;
    private int capacidadTripulacion;

    public NaveEspacial(int id, String nombre, Categoria categoria, int capacidadTripulacion) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.capacidadTripulacion = capacidadTripulacion;
    }

  
    @Override
    public int compareTo(NaveEspacial o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toCSV(){
        return id + "," + nombre + "," + capacidadTripulacion + "," + categoria.toString();
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }
    
    
    public static NaveEspacial fromCSV(String linea) {
        String[] data = linea.split(",");

        if (data.length != 4) {
            throw new IllegalArgumentException("La línea tiene un formato inesperado");
        }
        
        try {
            int id = Integer.parseInt(data[0]);
            String nombre = data[1];
            int capacidadTripulacion = Integer.parseInt(data[2]);
            Categoria categoria = Categoria.valueOf(data[3]);
           
            return new NaveEspacial(id, nombre, categoria, capacidadTripulacion);
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(ex.getMessage());
        }
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "id=" + id + ", nombre=" + nombre + ", categoria=" + categoria + ", capacidadTripulacion=" + capacidadTripulacion + '}';
    }

}