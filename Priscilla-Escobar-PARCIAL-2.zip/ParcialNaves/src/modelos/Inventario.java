
package modelos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Inventario<T> {
    private List<T> lista = new ArrayList<>();

    public void agregar(T value) {
        if (value == null) {
            throw new IllegalArgumentException("No se puede agregar un elemento nulo al inventario");
        }
        
        lista.add(value);
    }

    
    public void eliminarPorIndice(int indice) {
        validarIndice(indice);
        
        lista.remove(indice);
    }
    
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= lista.size()) {
            throw new IndexOutOfBoundsException("El indice no es valido");
        }
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : lista) {
            accion.accept(item);
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        
        for (T item : lista) {
            if (criterio.test(item)) {
                toReturn.add(item);
            }
        }
        
        return toReturn;
    }

    
    public void ordenar() {
        lista.sort(null);
    }

    public void ordenar(Comparator<? super T> comparador) {
        lista.sort(comparador);
    }
    
    
    public void guardarEnBinario(String path) throws IOException {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))) {
            output.writeObject(lista);
        }
    }

    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            lista = (List<T>) input.readObject();
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            writer.write("id,nombre,capacidadTripulacion,categoria\n");
            for (T item : lista) {
                if (item instanceof NaveEspacial) {
                    writer.write(((NaveEspacial) item).toCSV());
                    writer.newLine();
                }
            }
        }
    }
    
    
    public void cargarDesdeCSV(String path) throws IOException {
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            bf.readLine();

            String linea;
            while ((linea = bf.readLine()) != null) {
                if (linea.endsWith("\n")) {
                    linea = linea.substring(0, linea.length() - 1);
                }

                T libro = (T) NaveEspacial.fromCSV(linea);
                lista.add(libro);
            }
        }
    }
    
    public void limpiarLista(){
        lista.clear();
    }

}
