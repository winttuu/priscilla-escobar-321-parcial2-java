
package parcialnaves;

import java.io.IOException;
import modelos.Categoria;
import modelos.Inventario;
import modelos.NaveEspacial;


public class Test {

    public static void main(String[] args) {
        try {
            // Crear un inventario de naves espaciales
            Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
            
            inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", Categoria.CIENTIFICA, 50));
            inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", Categoria.TRANSPORTE, 12));
            inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", Categoria.MILITAR, 1));
            inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", Categoria.MILITAR, 34));
            inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", Categoria.CIENTIFICA, 100));
            inventarioNaves.agregar(new NaveEspacial(6, "TIE Fighter III", Categoria.MILITAR, 58));

            // Mostrar todas las naves en el inventario
            System.out.println("Inventario de naves espaciales:");
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

            // Filtrar naves por categoría CIENTIFICA
            System.out.println("\nNaves de la categoría CIENTIFICA:");
            inventarioNaves.filtrar(nave -> nave.getCategoria() == Categoria.CIENTIFICA)
            .forEach(nave -> System.out.println(nave));
            
            
            // Filtrar naves por categoría MILITAR
            System.out.println("\nNaves de la categoría MILITAR:");
            inventarioNaves.filtrar(nave -> nave.getCategoria() == Categoria.MILITAR)
            .forEach(nave -> System.out.println(nave));
            

            // Ordenar naves de manera natural (por id)
            System.out.println("\nNaves ordenadas de manera natural (por id):");
            inventarioNaves.ordenar();
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

            // Ordenar por nombre (menor a mayor)
            System.out.println("\nNaves ordenadas por nombre (menor a mayor):");
            inventarioNaves.ordenar((nave1, nave2) -> nave1.getNombre().compareTo(nave2.getNombre()));
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

            
            // Ordenar por capacidad de tripulación (menor a mayor)
            System.out.println("\nNaves ordenadas por capacidad de tripulación (menor a mayor):");
            inventarioNaves.ordenar((nave1, nave2) -> Integer.compare(nave1.getCapacidadTripulacion(), nave2.getCapacidadTripulacion()));
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

            
            // Cambiar la categoría de todas las naves a MILITAR
            System.out.println("\nNaves antes de transformar:");
            inventarioNaves.paraCadaElemento(System.out::println);

            inventarioNaves.paraCadaElemento(nave -> nave.setCategoria(Categoria.MILITAR));

            System.out.println("\nNaves después de transformar:");
            inventarioNaves.paraCadaElemento(System.out::println);

            // Guardar el inventario en un archivo binario
            inventarioNaves.guardarEnBinario("src/data/naves.dat");

            // Cargar el inventario desde el archivo binario
            Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
            
            inventarioCargado.cargarDesdeBinario("src/data/naves.dat");
            System.out.println("\nNaves cargadas desde archivo binario:");
            inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));
            
            
            // Guardar el inventario en un archivo CSV
            inventarioCargado.guardarEnCSV("src/data/naves.csv");

            
            inventarioCargado.limpiarLista();
            inventarioCargado.cargarDesdeCSV("src/data/naves.csv");
            System.out.println("\nNaves cargadas desde archivo CSV:");
            inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
}
